# csaw Detailed Workflow Guide

## Complete Analysis Pipeline

### Step 1: Software Installation and Setup

Install required R packages:

```r
# Install Bioconductor packages
if (!require("BiocManager", quietly = TRUE))
    install.packages("BiocManager")

BiocManager::install(c("csaw", "edgeR", "limma", "rtracklayer",
                       "ChIPseeker", "TxDb.Hsapiens.UCSC.hg38.knownGene",
                       "org.Hs.eg.db"))

# Install CRAN packages
install.packages(c("pheatmap", "ggplot2", "reshape2"))
```

### Step 2: Input File Preparation

#### BAM File Organization
Organize BAM files by condition:

```r
# Define BAM file paths
bam.files <- c(
  "control_rep1.bam", "control_rep2.bam", "control_rep3.bam",
  "treatment_rep1.bam", "treatment_rep2.bam", "treatment_rep3.bam"
)

# Define conditions
condition <- factor(c(rep("control", 3), rep("treatment", 3)))

# Create sample information
targets <- data.frame(
  FileName = bam.files,
  Condition = condition,
  Replicate = rep(1:3, 2)
)
```

#### Experimental Design
Define the experimental design matrix:

```r
# Simple two-group comparison
design <- model.matrix(~condition)

# With batch effects
design <- model.matrix(~condition + batch)

# Complex factorial design
design <- model.matrix(~treatment * time)
```

### Step 3: Read Counting

#### Window Parameter Selection

```r
library(csaw)

# Define counting parameters
param <- readParam(
  minq = 20,           # Minimum mapping quality
  dedup = TRUE,        # Remove duplicates
  pe = "both",         # Paired-end mode
  restrict = c("chr1", "chr2", "chr3", "chr4", "chr5",
               "chr6", "chr7", "chr8", "chr9", "chr10",
               "chr11", "chr12", "chr13", "chr14", "chr15",
               "chr16", "chr17", "chr18", "chr19", "chr20",
               "chr21", "chr22", "chrX", "chrY")  # Restrict to standard chromosomes
)

# Count reads in windows
win.data <- windowCounts(
  bam.files,
  ext = 200,           # Fragment length extension
  width = 150,         # Window size
  param = param,
  spacing = 50         # Distance between window centers
)
```

#### Background Estimation

Estimate background for filtering:

```r
# Use bin-based background
binned <- windowCounts(bam.files, bin=TRUE, width=10000, param=param)

# Or use input control
input.data <- windowCounts(input.bam.files, width=150, param=param)
```

### Step 4: Normalization

#### Composition Bias Correction

```r
# Loess-based normalization
win.data <- normOffsets(win.data, type="loess")

# TMM normalization
win.data <- normOffsets(win.data, type="TMM")

# Check normalization effectiveness
plotMA(assay(win.data)[,1:2], main="Before normalization")
plotMA(assay(win.data, with.offsets=TRUE)[,1:2], main="After normalization")
```

#### Library Size Adjustment

```r
# Convert to DGEList for edgeR analysis
y <- asDGEList(win.data)

# Check library sizes
summary(y$samples$lib.size)
barplot(y$samples$lib.size, names=colnames(y), las=2)
```

### Step 5: Filtering

#### Global Filtering

```r
# Filter based on abundance
keep <- filterWindows(win.data, background=binned, type="global")
win.data <- win.data[keep,]

# Check filtering
summary(keep)
```

#### Local Filtering

```r
# Filter based on local background
keep.local <- filterWindows(win.data, background=binned, type="local", width=5000)
win.data.local <- win.data[keep.local,]
```

### Step 6: Statistical Analysis

#### Dispersion Estimation

```r
# Estimate dispersion
y.filtered <- asDGEList(win.data)
y.filtered <- estimateDisp(y.filtered, design)

# Check dispersion estimates
plotBCV(y.filtered)
```

#### Model Fitting

```r
# Fit quasi-likelihood model
fit <- glmQLFit(y.filtered, design, robust=TRUE)

# Check model fit
plotQLDisp(fit)
```

#### Differential Testing

```r
# Test for differential binding
results <- glmQLFTest(fit, coef=2)

# Extract results
top.table <- topTags(results, n=Inf)
summary(decideTests(results))
```

### Step 7: Results Processing

#### Region Merging

```r
# Merge adjacent significant windows
merged <- mergeWindows(rowRanges(win.data), tol=1000)

# Combine test statistics
tabcom <- combineTests(merged$id, results$table)

# Filter significant regions
is.sig <- tabcom$FDR < 0.05
sig.regions <- merged$region[is.sig]

# Add statistics
mcols(sig.regions) <- tabcom[is.sig,]
```

#### Fold Change Calculation

```r
# Calculate log-fold changes
logFC <- getBestTest(merged$id, results$table)$logFC
mcols(sig.regions)$logFC <- logFC[is.sig]
```

### Step 8: Annotation

#### Genomic Feature Annotation

```r
library(ChIPseeker)
library(TxDb.Hsapiens.UCSC.hg38.knownGene)

# Annotate regions
annotated <- annotatePeak(
  sig.regions,
  tssRegion = c(-3000, 3000),
  TxDb = TxDb.Hsapiens.UCSC.hg38.knownGene,
  annoDb = "org.Hs.eg.db"
)

# View annotation summary
plotAnnoBar(annotated)
plotDistToTSS(annotated)
```

#### Gene Association

```r
# Extract gene annotations
gene.anno <- as.data.frame(annotated)

# Get nearest genes
nearest.genes <- genes(TxDb.Hsapiens.UCSC.hg38.knownGene)
nearest <- nearest(sig.regions, nearest.genes)
mcols(sig.regions)$nearest_gene <- names(nearest.genes)[nearest]
```

### Step 9: Visualization

#### MA Plots

```r
# MA plot of results
plotMD(results, status=decideTests(results), values=c(1,-1),
       col=c("red","blue"), main="Differential Binding")
```

#### Volcano Plots

```r
# Create volcano plot
volcano.data <- data.frame(
  logFC = top.table$table$logFC,
  logP = -log10(top.table$table$FDR)
)

library(ggplot2)
ggplot(volcano.data, aes(x=logFC, y=logP)) +
  geom_point(alpha=0.6) +
  geom_hline(yintercept=-log10(0.05), linetype="dashed") +
  labs(title="Volcano Plot", x="Log2 Fold Change", y="-Log10 FDR")
```

#### Heatmaps

```r
# Extract normalized counts for significant regions
norm.counts <- cpm(y.filtered, log=TRUE)
sig.counts <- norm.counts[is.sig,]

# Create heatmap
library(pheatmap)
pheatmap(sig.counts,
         scale="row",
         annotation_col = data.frame(Condition=condition),
         show_rownames = FALSE,
         main = "Differential Binding Heatmap")
```

### Step 10: Output Generation

#### Export Results

```r
# Export significant regions as BED
rtracklayer::export(sig.regions, "differential_regions.bed")

# Export full results table
write.csv(as.data.frame(sig.regions), "differential_binding_results.csv")

# Export annotation results
write.csv(as.data.frame(annotated), "annotated_regions.csv")
```

#### Session Information

```r
# Save session info for reproducibility
sink("session_info.txt")
sessionInfo()
sink()
```

## Quality Control Metrics

### Library Quality

```r
# Check mapping statistics
library(Rsamtools)
for (bam in bam.files) {
  stats <- idxstatsBam(bam)
  print(paste(bam, "total reads:", sum(stats$mapped)))
}
```

### Cross-correlation Analysis

```r
# Calculate cross-correlation
library(chipseq)
cc <- crossCorrelate(bam.files[1], shift=1:300)
plot(cc$shift, cc$correlation, type="l", main="Cross-correlation")
```

### FRiP Score

```r
# Calculate FRiP score
library(ChIPQC)
samples <- data.frame(SampleID=basename(bam.files),
                     Tissue=condition,
                     Factor="TF",
                     Replicate=rep(1:3,2),
                     bamReads=bam.files,
                     Peaks=NA)

chipobj <- ChIPQC(samples, annotation="hg38")
ChIPQCreport(chipobj)
```

## Advanced Analysis Options

### Multiple Testing Correction

```r
# Apply different FDR methods
fdr.bh <- p.adjust(results$table$PValue, method="BH")
fdr.qvalue <- qvalue::qvalue(results$table$PValue)$qvalues

# Compare methods
plot(fdr.bh, fdr.qvalue, xlab="BH FDR", ylab="q-value")
abline(0,1, col="red")
```

### Window Size Optimization

```r
# Test multiple window sizes
window.sizes <- c(50, 100, 150, 200, 250)
results.list <- list()

for (w in window.sizes) {
  win.test <- windowCounts(bam.files, width=w, param=param)
  win.test <- normOffsets(win.test)
  y.test <- asDGEList(win.test)
  y.test <- estimateDisp(y.test, design)
  fit.test <- glmQLFit(y.test, design)
  results.list[[as.character(w)]] <- glmQLFTest(fit.test, coef=2)
}

# Compare number of significant regions
sapply(results.list, function(x) sum(decideTests(x) != 0))
```

### Strand-specific Analysis

```r
# Count reads by strand
param.forward <- reform(param, forward=TRUE)
param.reverse <- reform(param, forward=FALSE)

win.forward <- windowCounts(bam.files, param=param.forward, width=150)
win.reverse <- windowCounts(bam.files, param=param.reverse, width=150)
```