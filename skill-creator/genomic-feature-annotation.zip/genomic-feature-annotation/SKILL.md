---
name: genomic-feature-annotation
description: This skill should be used when users need to annotate ChIP-seq or ATAC-seq peaks to genomic features using Homer (Hypergeometric Optimization of Motif EnRichment). It handles peak annotation to promoters, exons, introns, intergenic regions, TSS proximity, and other genomic features with comprehensive categorization and statistical analysis.
---

# Genomic Feature Annotation with Homer

## Overview

Perform comprehensive genomic feature annotation for ChIP-seq and ATAC-seq peak files using Homer's annotatePeaks.pl tool. This skill enables systematic categorization of genomic regions into functional categories including promoters, exons, introns, intergenic regions, and proximity to transcription start sites (TSS).

## Quick Start

To quickly annotate peaks using Homer:

```bash
annotatePeaks.pl peaks.bed hg38 > annotated_peaks.txt
```

## Core Workflow

### 1. Input File Preparation

Accept peak files in various formats:
- BED format (chr, start, end)
- NarrowPeak format (BED6+4)
- BroadPeak format (BED6+3)
- Homer peak files

Validate input files and ensure proper format:
```bash
# Check BED file format
head -n 5 peaks.bed
```

### 2. Genome Assembly Selection

Select appropriate genome assembly for annotation:
- Human: hg38, hg19
- Mouse: mm10, mm9
- Other genomes supported by Homer

Verify genome installation:
```bash
# Check available genomes
find $HOMER_DATA/genomes -type d -name "*hg38*"
```

### 3. Basic Peak Annotation

Perform comprehensive genomic annotation:
```bash
annotatePeaks.pl peaks.bed hg38 -annStats annotation_stats.txt > annotated_peaks.txt
```

Key parameters:
- `-annStats`: Generate annotation statistics
- `-size given`: Use original peak sizes
- `-hist`: Generate histogram of feature distances

### 4. TSS Proximity Analysis

Analyze peak proximity to transcription start sites:
```bash
annotatePeaks.pl peaks.bed hg38 -size 2000 -hist 10 > tss_proximity.txt
```

Parameters:
- `-size 2000`: Extend analysis window ±2kb from TSS
- `-hist 10`: Bin distances in 10bp increments

### 5. Advanced Annotation Options

#### Promoter-specific annotation:
```bash
annotatePeaks.pl peaks.bed hg38 -CpG > annotated_with_cpg.txt
```

#### Include custom annotations:
```bash
annotatePeaks.pl peaks.bed hg38 -ann custom_annotations.bed > custom_annotated.txt
```

#### Generate detailed statistics:
```bash
annotatePeaks.pl peaks.bed hg38 -annStats detailed_stats.txt -go gene_ontology.txt > full_annotation.txt
```

## Output Interpretation

### Annotation Categories

Understand Homer's genomic feature classification:
- **Promoter**: -1kb to +100bp from TSS
- **5' UTR**: 5' untranslated region
- **Exon**: Protein-coding exons
- **Intron**: Intronic regions
- **3' UTR**: 3' untranslated region
- **Intergenic**: Regions between genes
- **TTS**: Transcription termination sites

### Quality Metrics

Evaluate annotation quality:
- **Annotation rate**: Percentage of peaks successfully annotated
- **Promoter enrichment**: Expected vs observed promoter peaks
- **Intergenic fraction**: Background signal assessment

## Common Use Cases

### Transcription Factor ChIP-seq

For TF ChIP-seq, focus on promoter and proximal regions:
```bash
annotatePeaks.pl tf_peaks.bed hg38 -size 1000 -hist 50 > tf_annotation.txt
```

### Histone Mark ChIP-seq

For broad histone marks, include intergenic regions:
```bash
annotatePeaks.pl histone_peaks.bed hg38 -annStats histone_stats.txt > histone_annotation.txt
```

### ATAC-seq Accessibility

For ATAC-seq, analyze TSS proximity and enhancer regions:
```bash
annotatePeaks.pl atac_peaks.bed hg38 -size 5000 -hist 100 > atac_annotation.txt
```

## Troubleshooting

### Common Issues

1. **Genome not found**: Ensure Homer genome is installed
2. **Format errors**: Validate BED file format
3. **Memory issues**: Use `-cpu` parameter for parallel processing

### Error Resolution

```bash
# Check genome availability
find $HOMER_DATA -name "*.genes.txt" | head -5

# Validate BED file
awk '{if(NF<3) print "Line " NR " has only " NF " fields"}' peaks.bed
```

## Best Practices

### Input Quality
- Use filtered, high-quality peak calls
- Remove blacklisted regions
- Ensure proper peak calling parameters

### Analysis Parameters
- Choose appropriate window sizes for TSS analysis
- Use `-annStats` for quality assessment
- Consider biological context when interpreting results

### Output Management
- Save annotation statistics separately
- Document analysis parameters
- Use consistent file naming conventions

## Resources

This skill includes comprehensive reference documentation in `references/homer_annotation.md` covering:
- Complete parameter reference for annotatePeaks.pl
- Output format specifications
- Advanced usage scenarios
- Troubleshooting guides
- Performance optimization tips

Load the reference documentation when detailed parameter information or advanced usage guidance is needed.