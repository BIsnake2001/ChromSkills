# Homer Genomic Feature Annotation Reference

## Overview

Homer's `annotatePeaks.pl` tool provides comprehensive genomic annotation for ChIP-seq and ATAC-seq peak files. This reference covers command syntax, parameters, output formats, and advanced usage scenarios.

## Command Syntax

### Basic Command Structure

```bash
annotatePeaks.pl <peak file> <genome> [options] > output.txt
```

### Required Parameters

- **peak file**: BED, narrowPeak, broadPeak, or Homer peak file
- **genome**: Genome assembly (hg38, mm10, etc.)

## Parameter Reference

### Input/Output Options

- `-size <N>`: Set peak size (default: use original size)
  - `given`: Use original peak sizes
  - `200`: Extend peaks to 200bp
  - `-200,100`: From -200bp to +100bp relative to center

- `-annStats <file>`: Output annotation statistics
- `-go <file>`: Output gene ontology analysis
- `-cpu <N>`: Use multiple CPUs for processing

### Annotation Options

- `-CpG`: Include CpG island annotation
- `-gwas`: Include GWAS SNP annotation
- `-conservation`: Include conservation scores
- `-ann <file>`: Include custom annotation file
- `-m <motif file>`: Include motif scanning

### Distance Analysis

- `-hist <bin size>`: Generate distance histogram
- `-d <distance>`: Maximum distance for annotation
- `-noann`: Skip gene annotation (distance only)

### Gene-centric Options

- `-gene`: Output gene-centric annotation
- `-tss`: Use TSS instead of gene body
- `-strand <+/-/both>`: Strand specificity

## Output Format

### Main Annotation Columns

1. **PeakID**: Unique peak identifier
2. **Chr**: Chromosome
3. **Start**: Peak start position
4. **End**: Peak end position
5. **Strand**: Peak strand
6. **Peak Score**: Peak calling score
7. **Focus Ratio/Region Size**: Peak metrics
8. **Annotation**: Genomic feature
9. **Detailed Annotation**: Specific feature details
10. **Distance to TSS**: Distance to nearest TSS
11. **Nearest PromoterID**: Nearest gene
12. **Entrez ID**: Gene identifier
13. **Nearest Unigene**: Unigene identifier
14. **Nearest Refseq**: Refseq identifier
15. **Nearest Ensembl**: Ensembl identifier
16. **Gene Name**: Gene symbol
17. **Gene Alias**: Gene aliases
18. **Gene Description**: Gene description
19. **Gene Type**: Gene biotype

### Annotation Categories

Homer classifies peaks into these genomic features:

- **Promoter-TSS**: -1kb to +100bp from TSS
- **5' UTR**: 5' untranslated region
- **Exon**: Protein-coding exons
- **Intron**: Intronic regions
- **3' UTR**: 3' untranslated region
- **Downstream**: <300bp from transcription end
- **Intergenic**: Regions between genes
- **ncRNA**: Non-coding RNA genes
- **TTS**: Transcription termination sites

## Advanced Usage

### Batch Processing

```bash
# Process multiple files
for file in *.bed; do
    base=$(basename "$file" .bed)
    annotatePeaks.pl "$file" hg38 -annStats "${base}_stats.txt" > "${base}_annotated.txt"
done
```

### Custom Annotation

```bash
# Add custom genomic regions
annotatePeaks.pl peaks.bed hg38 -ann enhancers.bed -ann super_enhancers.bed > custom_annotated.txt
```

### Motif Integration

```bash
# Combine annotation with motif analysis
annotatePeaks.pl peaks.bed hg38 -m known.motifs > motif_annotated.txt
```

## Quality Control

### Annotation Statistics

The `-annStats` output provides:
- Total peaks annotated
- Distribution across genomic features
- Promoter enrichment scores
- Intergenic background levels

### Expected Distributions

- **TF ChIP-seq**: 20-40% promoter peaks
- **Histone marks**: Variable based on mark type
- **ATAC-seq**: 10-30% promoter peaks
- **Background**: High intergenic fraction

## Troubleshooting

### Common Errors

1. **"Can't find genome"**: Install Homer genome data
2. **Memory errors**: Use `-cpu` for parallel processing
3. **Format errors**: Validate BED file structure

### Validation Commands

```bash
# Check genome installation
find $HOMER_DATA -name "hg38*" -type d

# Validate peak file
wc -l peaks.bed
head -n 1 peaks.bed

# Check Homer installation
which annotatePeaks.pl
```

## Performance Optimization

### Memory Management

- Use `-cpu` for multi-core processing
- Process large files in batches
- Filter peaks before annotation

### File Size Considerations

- Large peak files (>100k peaks) may require splitting
- Use `head -n 10000` for testing parameters
- Consider peak filtering for quality control

## Integration with Other Tools

### Downstream Analysis

- Use annotated files for pathway analysis
- Integrate with DESeq2 for differential analysis
- Combine with GREAT for functional enrichment

### Visualization

- Import to genome browsers (IGV, UCSC)
- Use R/Bioconductor for statistical analysis
- Create pie charts for feature distributions