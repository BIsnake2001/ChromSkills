# csaw Results Interpretation Guide

## Understanding Output Files

### Key Output Components

1. **Statistical Results Table**: Contains p-values, FDR, log-fold changes
2. **Genomic Coordinates**: BED file with significant regions
3. **Annotation Results**: Genomic context of significant regions
4. **Visualization Plots**: MA plots, heatmaps, volcano plots

### Statistical Results Interpretation

```r
# Example results table structure
head(top.table$table)
```

**Columns to interpret:**
- `logFC`: Log2 fold change between conditions
- `logCPM`: Average log2 counts per million
- `F`: F-statistic value
- `PValue`: Raw p-value
- `FDR`: False Discovery Rate adjusted p-value

## Significance Criteria

### Statistical Significance

**Standard thresholds:**
- **FDR < 0.05**: Statistically significant
- **FDR < 0.01**: Highly significant
- **FDR < 0.001**: Very highly significant

**Interpretation:**
- FDR of 0.05 means 5% of significant regions are expected to be false positives
- More stringent thresholds reduce false positives but may miss true positives

### Biological Significance

**Fold change thresholds:**
- **|logFC| > 1**: 2-fold change (moderate)
- **|logFC| > 1.5**: ~3-fold change (substantial)
- **|logFC| > 2**: 4-fold change (strong)

**Context-dependent interpretation:**
- Strong TFs may show large fold changes
- Weak or cooperative TFs may show smaller changes
- Consider biological relevance alongside statistical significance

## Genomic Context Analysis

### Distribution Across Genomic Features

```r
# Analyze feature distribution
feature_counts <- table(annotated@anno$annotation)
print(feature_counts)

# Calculate enrichment
total_bases <- sum(width(sig.regions))
feature_enrichment <- feature_counts / total_bases
```

**Expected patterns for TFs:**
- **Promoters**: Common for many TFs
- **Enhancers**: Cell-type specific TFs
- **Introns**: Developmental regulators
- **Intergenic**: Pioneer factors

### Distance to TSS Analysis

```r
# Analyze distance to transcription start sites
distance_data <- annotated@anno$distanceToTSS
hist(distance_data, breaks=100, main="Distance to TSS")

# Calculate median distance
median_distance <- median(abs(distance_data))
print(paste("Median distance to TSS:", median_distance))
```

**Interpretation:**
- **< 1kb**: Promoter-proximal binding
- **1-10kb**: Enhancer regions
- **> 10kb**: Distal regulatory elements

## Functional Enrichment Analysis

### Gene Ontology Analysis

```r
library(clusterProfiler)

# Extract gene symbols
gene_symbols <- annotated@anno$SYMBOL
gene_symbols <- gene_symbols[!is.na(gene_symbols)]

# GO enrichment
go_results <- enrichGO(
  gene = gene_symbols,
  OrgDb = org.Hs.eg.db,
  ont = "BP",  # Biological Process
  pvalueCutoff = 0.05,
  qvalueCutoff = 0.05
)

# View top enriched terms
head(go_results)
```

**Interpretation of GO results:**
- **Enrichment score**: -log10(p-value)
- **Gene ratio**: Proportion of input genes in term
- **Count**: Number of genes in overlap
- **q-value**: Multiple testing corrected p-value

### Pathway Analysis

```r
# KEGG pathway enrichment
kegg_results <- enrichKEGG(
  gene = gene_symbols,
  organism = "hsa",
  pvalueCutoff = 0.05
)

# View enriched pathways
head(kegg_results)
```

## Quality Assessment

### Technical Quality Metrics

**Library quality indicators:**
- **Total reads**: >10 million per sample
- **Mapping rate**: >80%
- **FRiP score**: >1% for TFs
- **Cross-correlation**: Strong strand shift

**Analysis quality indicators:**
- **Number of significant regions**: Reasonable for biological context
- **Fold change distribution**: Bimodal for true differential binding
- **Genomic distribution**: Matches expected TF behavior

### Biological Validation

**Expected patterns:**
- Known TF targets should be enriched
- Cell-type specific binding should match expression
- Developmental TFs should show stage-specific patterns
- Disease-associated TFs should show relevant pathways

## Common Interpretation Scenarios

### Strong Differential Binding

**Characteristics:**
- High fold changes (|logFC| > 2)
- Low FDR values (< 0.001)
- Consistent across replicates
- Biologically plausible patterns

**Interpretation:**
- Likely true positive differential binding
- May represent key regulatory changes
- Good candidates for experimental validation

### Weak Differential Binding

**Characteristics:**
- Small fold changes (|logFC| < 1)
- Borderline FDR values (0.01-0.05)
- Inconsistent across replicates

**Interpretation:**
- May represent subtle regulatory changes
- Consider biological context and replication
- May require additional validation

### No Significant Binding

**Possible explanations:**
- Insufficient statistical power
- Poor data quality
- No true differential binding
- Inappropriate analysis parameters

**Troubleshooting:**
- Check library sizes and quality
- Verify experimental design
- Consider alternative analysis methods

## Integration with Other Data

### Correlation with Gene Expression

```r
# Load RNA-seq data
rna_data <- read.csv("rna_seq_results.csv")

# Match TF binding with gene expression
tf_genes <- unique(annotated@anno$SYMBOL)
rna_subset <- rna_data[rna_data$gene %in% tf_genes,]

# Calculate correlation
correlation <- cor(sig.regions$logFC, rna_subset$logFC, use="complete.obs")
print(paste("Correlation with expression:", correlation))
```

**Interpretation:**
- **Positive correlation**: Binding changes associated with expression changes
- **Negative correlation**: Repressive binding
- **No correlation**: Binding may not directly affect expression

### Comparison with Public Data

```r
# Load ENCODE or other public data
public_data <- import("public_tf_binding.bed")

# Calculate overlap
overlap <- findOverlaps(sig.regions, public_data)
overlap_percentage <- length(unique(queryHits(overlap))) / length(sig.regions)
print(paste("Overlap with public data:", round(overlap_percentage * 100, 1), "%"))
```

## Visualization Interpretation

### MA Plot Interpretation

**Expected patterns:**
- **Cloud centered at zero**: Good normalization
- **Vertical spread at low counts**: Technical noise
- **Horizontal spread at extremes**: True differential binding
- **Asymmetry**: May indicate normalization issues

### Volcano Plot Interpretation

**Quadrant analysis:**
- **Top right**: High fold change, high significance
- **Top left**: Negative fold change, high significance
- **Bottom center**: No significant changes
- **Outliers**: Potential artifacts or novel findings

### Heatmap Interpretation

**Cluster patterns:**
- **Condition-specific clusters**: Good separation between groups
- **Replicate clustering**: Technical reproducibility
- **Mixed clusters**: Batch effects or poor separation
- **Row patterns**: Co-regulated regions

## Reporting Guidelines

### Essential Information to Report

1. **Analysis parameters:**
   - Window size and spacing
   - Normalization method
   - Filtering criteria
   - Statistical thresholds

2. **Quality metrics:**
   - Library sizes and quality
   - Number of significant regions
   - Genomic distribution
   - Replication consistency

3. **Biological findings:**
   - Key differentially bound regions
   - Functional enrichment
   - Correlation with other data
   - Biological implications

### Common Pitfalls to Avoid

1. **Over-interpretation:**
   - Assuming all significant regions are functional
   - Ignoring multiple testing correction
   - Extrapolating beyond data

2. **Technical artifacts:**
   - Batch effects
   - Library size biases
   - Mapping artifacts
   - PCR duplicates

3. **Biological context:**
   - Ignoring cell-type specificity
   - Overlooking developmental timing
   - Missing tissue-specific effects

## Advanced Interpretation

### Time-course Analysis

```r
# Interpret temporal patterns
time_points <- c(0, 6, 12, 24, 48)  # hours
binding_patterns <- matrix(nrow=length(sig.regions), ncol=length(time_points))

# Classify temporal patterns
early_responders <- which(apply(binding_patterns[,1:2], 1, mean) > 2)
late_responders <- which(apply(binding_patterns[,4:5], 1, mean) > 2)
sustained <- which(apply(binding_patterns, 1, min) > 1)
```

### Multi-factor Analysis

```r
# Interpret interaction effects
interaction_effects <- results$table[results$table$FDR < 0.05 &
                                    abs(results$table$logFC.interaction) > 1,]

# Classify interaction patterns
synergistic <- interaction_effects[interaction_effects$logFC.interaction > 0,]
antagonistic <- interaction_effects[interaction_effects$logFC.interaction < 0,]
```