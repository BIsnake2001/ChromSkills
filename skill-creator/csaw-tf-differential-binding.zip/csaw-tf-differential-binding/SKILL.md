---
name: csaw-tf-differential-binding
description: This skill should be used when users need to perform differential transcription factor binding analysis from ChIP-seq data using the csaw package in R. It provides workflows for window-based read counting, normalization, statistical testing, and identification of differentially bound regions between conditions.
---

# csaw TF Differential Binding Analysis

## Overview

This skill enables comprehensive differential transcription factor binding analysis using the csaw package in R. csaw performs window-based read counting and statistical analysis to identify regions with significant differences in TF binding between experimental conditions.

## Quick Start

To perform csaw differential binding analysis:

1. **Prepare input data**: Aligned BAM files for TF ChIP-seq from multiple conditions
2. **Define experimental design**: Specify treatment and control groups
3. **Set analysis parameters**: Window size, normalization method, statistical thresholds
4. **Run csaw workflow**: Read counting → Normalization → Filtering → Statistical testing
5. **Interpret results**: Identify differentially bound regions, annotate, visualize

## Core Workflows

### 1. Data Preparation and Read Counting

Count reads in sliding windows across the genome:

```r
library(csaw)

# Define parameters
window_width <- 150
spacing <- 50

# Create window set
param <- readParam(minq=20, dedup=TRUE)
win.data <- windowCounts(bam.files, ext=200, width=window_width,
                         param=param, spacing=spacing)
```

**Parameters:**
- `window_width`: Size of counting windows (typically 50-200bp for TFs)
- `spacing`: Distance between window centers
- `ext`: Fragment length extension
- `minq`: Minimum mapping quality
- `dedup`: Remove PCR duplicates

### 2. Normalization and Filtering

Apply normalization and filter low-count regions:

```r
# Normalize for composition bias
win.data <- normOffsets(win.data, type="loess")

# Filter low-abundance windows
keep <- filterWindows(win.data, background, type="global")
win.data <- win.data[keep,]
```

**Normalization methods:**
- `"loess"`: Loess-based normalization
- `"TMM"`: Trimmed Mean of M-values
- `"RLE"`: Relative Log Expression

### 3. Statistical Testing

Test for differential binding:

```r
# Define design matrix
design <- model.matrix(~condition)

# Fit linear model
y <- asDGEList(win.data)
y <- estimateDisp(y, design)
fit <- glmQLFit(y, design, robust=TRUE)

# Test for differential binding
results <- glmQLFTest(fit, coef=2)
```

**Statistical options:**
- `glmQLFTest`: Quasi-likelihood F-test
- `glmTreat`: Treat test with fold-change threshold
- `edgeR`: Exact test for simple comparisons

### 4. Results Processing

Extract and annotate significant regions:

```r
# Extract results with FDR control
merged <- mergeWindows(rowRanges(win.data), tol=1000)
tabcom <- combineTests(merged$id, results$table)

# Filter significant regions
sig.regions <- merged$region[tabcom$FDR < 0.05]

# Annotate with genomic features
library(ChIPseeker)
annotated <- annotatePeak(sig.regions, TxDb=txdb)
```

## Parameter Optimization

### Window Size Selection

Determine optimal window size for TF binding:

```r
# Test multiple window sizes
window_sizes <- c(50, 100, 150, 200)
for (w in window_sizes) {
  win.data <- windowCounts(bam.files, width=w, param=param)
  # Evaluate window size performance
}
```

**Guidelines:**
- **Narrow TFs**: 50-100bp windows
- **Broad TFs**: 150-200bp windows
- **Histone marks**: 500-1000bp windows

### Filtering Thresholds

Optimize filtering parameters:

```r
# Test different filtering strategies
keep1 <- filterWindows(win.data, background, type="global", prior.count=5)
keep2 <- filterWindows(win.data, background, type="local", width=5000)
```

## Quality Control

### Library Complexity

Assess library quality and complexity:

```r
# Check library sizes
summary(y$samples$lib.size)

# Assess normalization
plotMDS(y, col=as.numeric(condition))

# Check dispersion estimates
plotBCV(y)
```

### Model Diagnostics

Validate statistical models:

```r
# Check model fit
plotQLDisp(fit)

# Assess normalization
plotMD(fit, column=2, status=is.de)
```

## Multi-group Analysis

### Complex Experimental Designs

Handle multiple conditions and timepoints:

```r
# Multi-factor design
design <- model.matrix(~treatment + time + treatment:time)

# Contrast definitions
contrast <- makeContrasts(
  treatment_effect = treatmentB - treatmentA,
  time_effect = time24h - time0h,
  interaction = (treatmentB - treatmentA):(time24h - time0h),
  levels=design
)
```

### Pairwise Comparisons

Perform all pairwise comparisons:

```r
# Create all pairwise contrasts
library(limma)
contrasts <- makeContrasts(
  BvsA = B - A,
  CvsA = C - A,
  CvsB = C - B,
  levels=design
)

# Test each contrast
results.list <- list()
for (i in 1:ncol(contrasts)) {
  results.list[[i]] <- glmQLFTest(fit, contrast=contrasts[,i])
}
```

## Results Interpretation

### Significance Criteria

Define thresholds for differential binding:

- **FDR < 0.05**: Statistical significance
- **Fold change > 2**: Biological significance
- **Minimum count**: Sufficient read support

### Genomic Context

Interpret results in biological context:

```r
# Distribution across genomic features
plotAnnoBar(annotated)

# Distance to TSS
plotDistToTSS(annotated)

# Functional enrichment
library(clusterProfiler)
enrichGO(geneList, OrgDb=orgDb, ont="BP")
```

## Visualization

### MA Plots

Visualize differential binding:

```r
# MA plot with significance
plotMD(results, status=is.de, values=c(1,-1),
       col=c("red","blue"), main="Differential Binding")
```

### Heatmaps

Cluster binding patterns:

```r
# Extract normalized counts
norm.counts <- cpm(y, log=TRUE)

# Create heatmap
library(pheatmap)
pheatmap(norm.counts[is.de,], scale="row",
         annotation_col=sample.info)
```

### Genome Browser Tracks

Generate tracks for visualization:

```r
# Export significant regions as BED
rtracklayer::export(sig.regions, "differential_regions.bed")

# Create coverage tracks
cov <- coverage(bam.files)
rtracklayer::export(cov, "coverage.bw")
```

## Troubleshooting

### Common Issues

1. **Low power**: Increase sequencing depth or reduce FDR threshold
2. **Batch effects**: Include batch in design matrix
3. **Over-dispersion**: Use robust estimation in glmQLFit
4. **Normalization problems**: Try different normalization methods

### Error Handling

- Ensure BAM files are properly indexed
- Verify experimental design matrix is full rank
- Check for sufficient replication in each condition
- Validate normalization assumptions with diagnostic plots

## Advanced Workflows

### Integration with Other Data

Combine with:
- RNA-seq for expression correlation
- ATAC-seq for accessibility validation
- Motif analysis for TF specificity
- Hi-C for 3D chromatin context

### Time-series Analysis

Model temporal binding changes:

```r
# Spline-based time modeling
library(splines)
design <- model.matrix(~ns(time, df=3))
fit <- glmQLFit(y, design)
```

### Peak-based Analysis

Combine with peak calling:

```r
# Use called peaks as regions of interest
peaks <- readNarrowpeaks("peaks.narrowPeak")
peak.data <- regionCounts(bam.files, regions=peaks, param=param)
```
