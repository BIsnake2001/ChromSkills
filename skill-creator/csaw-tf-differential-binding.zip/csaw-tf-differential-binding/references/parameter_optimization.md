# csaw Parameter Optimization Guide

## Window Size Selection

### Impact of Window Size

| Window Size | Resolution | Sensitivity | Specificity | Use Cases |
|-------------|------------|-------------|-------------|-----------|
| 50bp | Very High | High | Low | Narrow TF binding sites |
| 100bp | High | High | Medium | Most transcription factors |
| 150bp | Standard | Balanced | Balanced | General TF analysis |
| 200bp | Medium | Medium | High | Broad TF binding |
| 500bp | Low | Low | Very High | Histone marks |

### Systematic Window Size Testing

```r
# Test multiple window sizes
window_sizes <- c(50, 100, 150, 200, 250)
performance_metrics <- data.frame()

for (w in window_sizes) {
  # Count reads
  win.data <- windowCounts(bam.files, width=w, param=param)

  # Normalize and filter
  win.data <- normOffsets(win.data)
  keep <- filterWindows(win.data, background, type="global")
  win.data <- win.data[keep,]

  # Statistical testing
  y <- asDGEList(win.data)
  y <- estimateDisp(y, design)
  fit <- glmQLFit(y, design)
  results <- glmQLFTest(fit, coef=2)

  # Calculate metrics
  n_sig <- sum(decideTests(results) != 0)
  mean_width <- mean(width(rowRanges(win.data)[decideTests(results) != 0]))

  performance_metrics <- rbind(performance_metrics,
                               data.frame(WindowSize=w,
                                         SignificantRegions=n_sig,
                                         MeanWidth=mean_width))
}

# Plot performance
library(ggplot2)
ggplot(performance_metrics, aes(x=WindowSize, y=SignificantRegions)) +
  geom_line() + geom_point() +
  labs(title="Window Size vs Significant Regions",
       x="Window Size (bp)", y="Number of Significant Regions")
```

### Optimal Window Size Criteria

1. **Biological relevance**: Match expected TF binding site size
2. **Statistical power**: Sufficient reads per window
3. **Resolution**: Appropriate for biological question
4. **Computational efficiency**: Balance sensitivity and runtime

## Spacing Parameter Optimization

### Spacing Impact

```r
# Test different spacing parameters
spacings <- c(10, 25, 50, 100)
spacing_results <- list()

for (s in spacings) {
  win.data <- windowCounts(bam.files, width=150, spacing=s, param=param)
  # Continue with analysis...
  spacing_results[[as.character(s)]] <- win.data
}

# Compare window counts
sapply(spacing_results, nrow)
```

**Guidelines:**
- **10-25bp**: High resolution, more windows
- **50bp**: Standard spacing
- **100bp**: Low resolution, fewer windows

## Normalization Method Selection

### Comparison of Normalization Methods

```r
# Test different normalization methods
methods <- c("loess", "TMM", "RLE")
normalization_results <- list()

for (method in methods) {
  win.data <- windowCounts(bam.files, width=150, param=param)
  win.norm <- normOffsets(win.data, type=method)

  # Evaluate normalization
  y <- asDGEList(win.norm)
  plotMDS(y, main=method)

  normalization_results[[method]] <- win.norm
}
```

### Normalization Performance Metrics

1. **Library size distribution**: Should be similar after normalization
2. **MA plots**: Should be centered around zero
3. **MDS plots**: Samples should cluster by condition, not library size

## Filtering Strategy Optimization

### Global vs Local Filtering

```r
# Compare filtering strategies
filter_methods <- list(
  global = filterWindows(win.data, background, type="global"),
  local_1kb = filterWindows(win.data, background, type="local", width=1000),
  local_5kb = filterWindows(win.data, background, type="local", width=5000),
  local_10kb = filterWindows(win.data, background, type="local", width=10000)
)

# Compare number of retained windows
sapply(filter_methods, sum)
```

### Filtering Threshold Selection

```r
# Test different abundance thresholds
thresholds <- c(1, 3, 5, 10)
threshold_results <- list()

for (thresh in thresholds) {
  keep <- filterWindows(win.data, background, type="global", prior.count=thresh)
  win.filtered <- win.data[keep,]

  # Continue with analysis
  y <- asDGEList(win.filtered)
  y <- estimateDisp(y, design)
  fit <- glmQLFit(y, design)
  results <- glmQLFTest(fit, coef=2)

  threshold_results[[as.character(thresh)]] <- results
}

# Compare results
sapply(threshold_results, function(x) sum(decideTests(x) != 0))
```

## Statistical Parameter Tuning

### Dispersion Estimation

```r
# Compare dispersion estimation methods
y <- asDGEList(win.data)

# Common dispersion
y.common <- estimateCommonDisp(y, design)

# Tagwise dispersion
y.tagwise <- estimateTagwiseDisp(y, design)

# Trended dispersion
y.trended <- estimateTrendedDisp(y, design)

# Compare dispersion estimates
plotBCV(y.common, main="Common Dispersion")
plotBCV(y.tagwise, main="Tagwise Dispersion")
plotBCV(y.trended, main="Trended Dispersion")
```

### Robust Estimation

```r
# Test robust vs non-robust estimation
fit.robust <- glmQLFit(y, design, robust=TRUE)
fit.nonrobust <- glmQLFit(y, design, robust=FALSE)

# Compare results
results.robust <- glmQLFTest(fit.robust, coef=2)
results.nonrobust <- glmQLFTest(fit.nonrobust, coef=2)

# Compare number of significant regions
c(Robust=sum(decideTests(results.robust) != 0),
  NonRobust=sum(decideTests(results.nonrobust) != 0))
```

## Multiple Testing Correction

### FDR Threshold Selection

```r
# Test different FDR thresholds
fdr_thresholds <- c(0.01, 0.05, 0.1, 0.2)
fdr_results <- list()

for (fdr in fdr_thresholds) {
  is.sig <- results$table$FDR < fdr
  sig.regions <- rowRanges(win.data)[is.sig]

  fdr_results[[as.character(fdr)]] <- list(
    n_regions = length(sig.regions),
    mean_fc = mean(abs(results$table$logFC[is.sig]))
  )
}

# Compare results
fdr_comparison <- do.call(rbind, fdr_results)
print(fdr_comparison)
```

### Fold Change Thresholds

```r
# Apply fold change filtering
fc_thresholds <- c(1, 1.5, 2, 2.5)
fc_results <- list()

for (fc in fc_thresholds) {
  is.sig.fc <- (results$table$FDR < 0.05) & (abs(results$table$logFC) > fc)
  sig.regions.fc <- rowRanges(win.data)[is.sig.fc]

  fc_results[[as.character(fc)]] <- length(sig.regions.fc)
}

# Plot results
plot(names(fc_results), unlist(fc_results), type="b",
     xlab="Fold Change Threshold", ylab="Number of Significant Regions")
```

## Region Merging Parameters

### Tolerance Distance Optimization

```r
# Test different merging tolerances
tolerances <- c(100, 500, 1000, 2000, 5000)
merge_results <- list()

for (tol in tolerances) {
  merged <- mergeWindows(rowRanges(win.data), tol=tol)

  merge_results[[as.character(tol)]] <- list(
    n_regions = length(merged$region),
    mean_width = mean(width(merged$region))
  )
}

# Compare merging performance
merge_comparison <- do.call(rbind, merge_results)
print(merge_comparison)
```

### Optimal Tolerance Selection

1. **Small tolerance (100-500bp)**: Preserve individual binding sites
2. **Medium tolerance (1000-2000bp)**: Merge nearby sites, maintain resolution
3. **Large tolerance (>2000bp)**: Create large domains, reduce resolution

## Quality Control Parameter Optimization

### Library Size Requirements

```r
# Assess minimum library size
library_sizes <- y$samples$lib.size
min_lib_size <- min(library_sizes)

# Calculate required depth
required_reads <- 10e6  # 10 million reads minimum
if (min_lib_size < required_reads) {
  warning("Some libraries have low depth. Consider excluding or increasing sequencing depth.")
}
```

### Replication Requirements

```r
# Check replication
n_replicates <- table(condition)
min_replicates <- min(n_replicates)

if (min_replicates < 2) {
  stop("Insufficient replication for statistical testing")
} else if (min_replicates == 2) {
  warning("Low replication may limit statistical power")
}
```

## Automated Parameter Selection

### Grid Search Optimization

```r
# Define parameter grid
param_grid <- expand.grid(
  window_size = c(100, 150, 200),
  spacing = c(25, 50, 100),
  normalization = c("loess", "TMM"),
  filtering = c("global", "local")
)

# Perform grid search
best_params <- NULL
best_score <- -Inf

for (i in 1:nrow(param_grid)) {
  params <- param_grid[i,]

  tryCatch({
    # Run analysis with current parameters
    result <- run_csaw_analysis(bam.files, design, params)

    # Calculate performance score
    score <- calculate_performance_score(result)

    # Update best parameters
    if (score > best_score) {
      best_score <- score
      best_params <- params
    }
  }, error = function(e) {
    # Skip parameters that cause errors
    warning(paste("Parameters failed:", paste(params, collapse=", ")))
  })
}

print("Best parameters:")
print(best_params)
print(paste("Best score:", best_score))
```

### Performance Metrics

Define performance scoring function:

```r
calculate_performance_score <- function(results) {
  # Balance between sensitivity and specificity
  n_sig <- sum(decideTests(results) != 0)
  mean_fc <- mean(abs(results$table$logFC[decideTests(results) != 0]))

  # Penalize extreme values
  if (n_sig < 100) score <- -Inf  # Too few regions
  else if (n_sig > 10000) score <- -Inf  # Too many regions
  else score <- n_sig * log(mean_fc)  # Combined metric

  return(score)
}
```