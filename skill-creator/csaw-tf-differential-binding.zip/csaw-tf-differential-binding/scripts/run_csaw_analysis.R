#!/usr/bin/env Rscript

# csaw TF Differential Binding Analysis Script
# Complete workflow for differential transcription factor binding analysis

suppressPackageStartupMessages({
  library(csaw)
  library(edgeR)
  library(limma)
  library(rtracklayer)
  library(ChIPseeker)
  library(TxDb.Hsapiens.UCSC.hg38.knownGene)
  library(org.Hs.eg.db)
  library(ggplot2)
  library(pheatmap)
})

# Parse command line arguments
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 2) {
  stop("Usage: Rscript run_csaw_analysis.R <bam_directory> <output_directory> [options]\n",
       "Options:\n",
       "  --window-size SIZE      Window size in bp (default: 150)\n",
       "  --spacing SIZE          Spacing between windows (default: 50)\n",
       "  --fdr-threshold FDR     FDR threshold (default: 0.05)\n",
       "  --fc-threshold FC       Fold change threshold (default: 1)\n",
       "  --design-file FILE      Experimental design file\n",
       "  --genome ASSEMBLY       Genome assembly (default: hg38)")
}

bam_dir <- args[1]
output_dir <- args[2]

# Default parameters
window_size <- 150
spacing <- 50
fdr_threshold <- 0.05
fc_threshold <- 1
genome_assembly <- "hg38"
design_file <- NULL

# Parse optional arguments
if (length(args) > 2) {
  i <- 3
  while (i <= length(args)) {
    if (args[i] == "--window-size") {
      window_size <- as.numeric(args[i + 1])
      i <- i + 2
    } else if (args[i] == "--spacing") {
      spacing <- as.numeric(args[i + 1])
      i <- i + 2
    } else if (args[i] == "--fdr-threshold") {
      fdr_threshold <- as.numeric(args[i + 1])
      i <- i + 2
    } else if (args[i] == "--fc-threshold") {
      fc_threshold <- as.numeric(args[i + 1])
      i <- i + 2
    } else if (args[i] == "--design-file") {
      design_file <- args[i + 1]
      i <- i + 2
    } else if (args[i] == "--genome") {
      genome_assembly <- args[i + 1]
      i <- i + 2
    } else {
      stop("Unknown option: ", args[i])
    }
  }
}

# Create output directory
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# Log parameters
log_file <- file.path(output_dir, "analysis_log.txt")
sink(log_file)
cat("csaw TF Differential Binding Analysis\n")
cat("=====================================\n")
cat("Parameters:\n")
cat("  Window size:", window_size, "bp\n")
cat("  Spacing:", spacing, "bp\n")
cat("  FDR threshold:", fdr_threshold, "\n")
cat("  Fold change threshold:", fc_threshold, "\n")
cat("  Genome assembly:", genome_assembly, "\n")
cat("  Output directory:", output_dir, "\n\n")

# Load BAM files
cat("Loading BAM files...\n")
bam_files <- list.files(bam_dir, pattern = "\\.bam$", full.names = TRUE)
if (length(bam_files) == 0) {
  stop("No BAM files found in directory: ", bam_dir)
}
cat("Found", length(bam_files), "BAM files\n")

# Load experimental design
if (!is.null(design_file)) {
  design_info <- read.csv(design_file)
  conditions <- design_info$condition
  cat("Loaded experimental design from:", design_file, "\n")
} else {
  # Default: assume first half are control, second half are treatment
  n_samples <- length(bam_files)
  conditions <- factor(c(rep("control", n_samples/2), rep("treatment", n_samples/2)))
  cat("Using default experimental design\n")
}

cat("Conditions:", paste(levels(conditions), collapse=", "), "\n\n")

# Step 1: Read Counting
cat("Step 1: Counting reads in windows...\n")
param <- readParam(
  minq = 20,
  dedup = TRUE,
  restrict = standardChromosomes(TxDb.Hsapiens.UCSC.hg38.knownGene)
)

win.data <- windowCounts(
  bam.files = bam_files,
  ext = 200,
  width = window_size,
  param = param,
  spacing = spacing
)

cat("Created", nrow(win.data), "windows\n")

# Step 2: Normalization
cat("Step 2: Normalizing data...\n")
win.data <- normOffsets(win.data, type = "loess")

# Step 3: Filtering
cat("Step 3: Filtering low-count windows...\n")
binned <- windowCounts(bam_files, bin = TRUE, width = 10000, param = param)
keep <- filterWindows(win.data, background = binned, type = "global")
win.data <- win.data[keep,]

cat("Retained", nrow(win.data), "windows after filtering\n")

# Step 4: Statistical Analysis
cat("Step 4: Statistical testing...\n")

# Create design matrix
design <- model.matrix(~conditions)

# Convert to DGEList and estimate dispersion
y <- asDGEList(win.data)
y <- estimateDisp(y, design)

# Fit model and test
fit <- glmQLFit(y, design, robust = TRUE)
results <- glmQLFTest(fit, coef = 2)

# Extract results
top.table <- topTags(results, n = Inf)

# Step 5: Results Processing
cat("Step 5: Processing results...\n")

# Merge windows
merged <- mergeWindows(rowRanges(win.data), tol = 1000)
tabcom <- combineTests(merged$id, results$table)

# Filter significant regions
is.sig <- tabcom$FDR < fdr_threshold & abs(tabcom$logFC) > fc_threshold
sig.regions <- merged$region[is.sig]
mcols(sig.regions) <- tabcom[is.sig,]

cat("Found", length(sig.regions), "significant regions\n")

# Step 6: Annotation
cat("Step 6: Annotating regions...\n")

if (genome_assembly == "hg38") {
  txdb <- TxDb.Hsapiens.UCSC.hg38.knownGene
} else if (genome_assembly == "hg19") {
  txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene
} else if (genome_assembly == "mm10") {
  txdb <- TxDb.Mmusculus.UCSC.mm10.knownGene
} else {
  stop("Unsupported genome assembly: ", genome_assembly)
}

annotated <- annotatePeak(
  sig.regions,
  tssRegion = c(-3000, 3000),
  TxDb = txdb,
  annoDb = "org.Hs.eg.db"
)

# Step 7: Visualization
cat("Step 7: Creating visualizations...\n")

# MA plot
png(file.path(output_dir, "ma_plot.png"), width = 800, height = 600)
plotMD(results, status = decideTests(results), values = c(1, -1),
       col = c("red", "blue"), main = "Differential Binding MA Plot")
dev.off()

# Volcano plot
volcano_data <- data.frame(
  logFC = top.table$table$logFC,
  logP = -log10(top.table$table$FDR)
)

ggplot(volcano_data, aes(x = logFC, y = logP)) +
  geom_point(alpha = 0.6, color = ifelse(abs(top.table$table$logFC) > fc_threshold &
                                         top.table$table$FDR < fdr_threshold,
                                       "red", "black")) +
  geom_hline(yintercept = -log10(fdr_threshold), linetype = "dashed") +
  geom_vline(xintercept = c(-fc_threshold, fc_threshold), linetype = "dashed") +
  labs(title = "Volcano Plot", x = "Log2 Fold Change", y = "-Log10 FDR") +
  theme_minimal()

ggsave(file.path(output_dir, "volcano_plot.png"), width = 8, height = 6)

# Heatmap
if (length(sig.regions) > 0) {
  norm.counts <- cpm(y, log = TRUE)
  sig.counts <- norm.counts[is.sig,]

  if (nrow(sig.counts) > 1) {
    annotation_col <- data.frame(Condition = conditions)
    rownames(annotation_col) <- colnames(sig.counts)

    pheatmap(sig.counts,
             scale = "row",
             annotation_col = annotation_col,
             show_rownames = FALSE,
             main = "Differential Binding Heatmap",
             filename = file.path(output_dir, "heatmap.png"))
  }
}

# Step 8: Output Generation
cat("Step 8: Generating output files...\n")

# Export significant regions
rtracklayer::export(sig.regions, file.path(output_dir, "differential_regions.bed"))

# Export full results
write.csv(as.data.frame(sig.regions),
          file.path(output_dir, "differential_binding_results.csv"),
          row.names = FALSE)

# Export annotation results
write.csv(as.data.frame(annotated),
          file.path(output_dir, "annotated_regions.csv"),
          row.names = FALSE)

# Export summary statistics
summary_stats <- data.frame(
  Metric = c("Total Windows", "Significant Regions", "Up-regulated", "Down-regulated"),
  Count = c(nrow(win.data), length(sig.regions),
            sum(sig.regions$logFC > 0), sum(sig.regions$logFC < 0))
)

write.csv(summary_stats, file.path(output_dir, "summary_statistics.csv"), row.names = FALSE)

# Create annotation summary
if (length(sig.regions) > 0) {
  png(file.path(output_dir, "annotation_summary.png"), width = 800, height = 600)
  plotAnnoBar(annotated)
  dev.off()

  png(file.path(output_dir, "distance_to_tss.png"), width = 800, height = 600)
  plotDistToTSS(annotated)
  dev.off()
}

# Save session info
sink(file.path(output_dir, "session_info.txt"))
sessionInfo()
sink()

sink()  # Close log file

cat("Analysis completed successfully!\n")
cat("Output files saved to:", output_dir, "\n")
cat("Summary:\n")
cat("  Total windows:", nrow(win.data), "\n")
cat("  Significant regions:", length(sig.regions), "\n")
cat("  Up-regulated:", sum(sig.regions$logFC > 0), "\n")
cat("  Down-regulated:", sum(sig.regions$logFC < 0), "\n")

# Print session info to console
cat("\nSession information saved to session_info.txt\n")

# Return success
quit(status = 0)